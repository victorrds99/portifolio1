export * from './modal-cotacao.component';
