export * from './editar-tarefa.component';
