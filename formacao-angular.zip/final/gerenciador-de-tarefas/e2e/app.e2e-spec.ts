import { GerenciadorDeTarefasPage } from './app.po';

describe('gerenciador-de-tarefas App', () => {
  let page: GerenciadorDeTarefasPage;

  beforeEach(() => {
    page = new GerenciadorDeTarefasPage();
  });

});
