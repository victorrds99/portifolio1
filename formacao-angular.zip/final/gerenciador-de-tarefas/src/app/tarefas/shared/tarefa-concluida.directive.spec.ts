import { TarefaConcluidaDirective } from './tarefa-concluida.directive';

describe('TarefaConcluidaDirective', () => {
  it('should create an instance', () => {
    const directive = new TarefaConcluidaDirective();
    expect(directive).toBeTruthy();
  });
});
