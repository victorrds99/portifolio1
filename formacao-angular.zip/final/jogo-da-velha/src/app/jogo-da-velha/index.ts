export * from './jogo-da-velha.module';
export * from './jogo-da-velha.component';
export * from './shared';
