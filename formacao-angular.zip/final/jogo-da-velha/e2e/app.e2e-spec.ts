import { JogoDaVelhaPage } from './app.po';

describe('jogo-da-velha App', () => {
  let page: JogoDaVelhaPage;

  beforeEach(() => {
    page = new JogoDaVelhaPage();
  });

});
