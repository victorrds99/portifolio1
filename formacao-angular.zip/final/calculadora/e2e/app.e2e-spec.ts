import { CalculadoraPage } from './app.po';

describe('calculadora App', () => {
  let page: CalculadoraPage;

  beforeEach(() => {
    page = new CalculadoraPage();
  });

});
