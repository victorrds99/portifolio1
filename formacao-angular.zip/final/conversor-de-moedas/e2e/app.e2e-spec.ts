import { ConversorDeMoedasPage } from './app.po';

describe('conversor-de-moedas App', () => {
  let page: ConversorDeMoedasPage;

  beforeEach(() => {
    page = new ConversorDeMoedasPage();
  });

});
