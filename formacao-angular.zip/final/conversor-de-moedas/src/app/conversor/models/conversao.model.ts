export class Conversao {

	constructor(
		public moedaDe?: string,
		public moedaPara?: string,
		public valor?: number) {}
}
