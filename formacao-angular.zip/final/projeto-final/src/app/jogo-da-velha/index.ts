export * from './jogo-da-velha.module';
export * from './jogo-da-velha.component';
export * from './shared';
export * from './jogo-da-velha-routing.module';
export * from './jogo-da-velha-routing.component';
