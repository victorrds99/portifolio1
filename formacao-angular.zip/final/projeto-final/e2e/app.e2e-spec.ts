import { ProjetoFinalPage } from './app.po';

describe('projeto-final App', () => {
  let page: ProjetoFinalPage;

  beforeEach(() => {
    page = new ProjetoFinalPage();
  });

});
